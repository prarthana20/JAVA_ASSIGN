package com.hexaware.main;

import com.hexaware.controller.OopController;
import java.util.Scanner;
import com.hexaware.entity.OopModel;
import com.hexaware.view.OopView;
import com.hexaware.entity.BankTransactionM;
import com.hexaware.view.BankTransactionV;
import com.hexaware.controller.BankTransactionC;


public class MainApplication {
	public static void main(String[] args) {
		
		//TASK-1
        
		OopModel model = new OopModel();
        OopView view = new OopView();
        OopController controller = new OopController(model, view);
        controller.LoanEligibility();
        
        //TASK-2
        
        model.setBalance(1000);
		controller.performTransaction();
		
		//TASK-3
		
		int numberOfCustomers = 2; 
		for (int i = 1; i <= numberOfCustomers; i++) {
            System.out.println("\nCustomer " + i);
            controller.calculateFutureBalance();
            }
		
		//TASK-4
		
		controller.checkBalance();
		
		//TASK-5
		
		controller.validatePassword();
		
		//TASK-6
		
		BankTransactionM model1 = new BankTransactionM();
        BankTransactionV view1 = new BankTransactionV();
        BankTransactionC controller1 = new BankTransactionC(model1, view1);
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("\nEnter transaction amount: ");
            double amount = scanner.nextDouble();
            if (amount == 0) {
                break;
            }
            controller1.addTransaction(amount);
        }
        controller1.displayTransactions();
        System.out.println("\nExiting the program.");
    }
}	

