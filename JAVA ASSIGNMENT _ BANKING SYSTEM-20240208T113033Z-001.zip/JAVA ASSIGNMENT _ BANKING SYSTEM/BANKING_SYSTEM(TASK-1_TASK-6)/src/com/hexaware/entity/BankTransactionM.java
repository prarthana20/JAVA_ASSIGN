package com.hexaware.entity;

import java.util.List;

public class BankTransactionM {

	public double addTransaction(double amount) {
		return amount;
		
	}

	public List<Double> getTransactions() {
		// TODO Auto-generated method stub
		return null;
	}


}
