package com.hexaware.entity;

import java.util.List;
import java.util.ArrayList;

public class OopModel {

		//TASK-1
	
	    private double annualIncome;
	    private int creditScore;
	    public double getAnnualIncome() {
	        return annualIncome;
	    }
	    public int getcreditScore() {
	        return creditScore;
	    }
	    public void setAnnualIncome(double annualIncome) {
	        this.annualIncome = annualIncome;
	    }
	    public void setcreditScore(int creditScore) {
	        this.creditScore = creditScore;
	    }
	    public boolean checkEligibility() {
	        return annualIncome >= 50000 && creditScore > 700;
	    }
	    
	    //TASK-2
	    
	    private double balance;
	    public double getBalance() {
			return balance;
		 }
	    public void setBalance(double balance) {
			this.balance = balance;
		 }
	    
		//TASK-3
		
		private double initialBalance;
	    private double annualInterestRate;
	    private int years;
	    private double futureBalance;
	    public double getInitialBalance() {
	        return initialBalance;
	    }
	    public void setInitialBalance(double initialBalance) {
	        this.initialBalance = initialBalance;
	    }
	    public double getAnnualInterestRate() {
	        return annualInterestRate;
	    }
	    public void setAnnualInterestRate(double annualInterestRate) {
	        this.annualInterestRate = annualInterestRate;
	    }
	    public int getYears() {
	        return years;
	    }
	    public void setYears(int years) {
	        this.years = years;
	    }
	    public double getFutureBalance() {
	        return futureBalance;
	    }
	    public void calculateFutureBalance() {
	        futureBalance = initialBalance * Math.pow((1 + annualInterestRate / 100), years);
	    }
	    
	    //TASK-4
	    
	    private String[] validAccountNumbers = {"A123", "B456", "C789"};
	    private double[] accountBalances = {1000, 2000, 3000};
	    public boolean isValidAccount(String accountNumber) {
	        for (String validAccount : validAccountNumbers) {
	            if (validAccount.equals(accountNumber)) {
	                return true;
	            }
	        }
	        return false;
	    }
	    public double getAccountBalance(String accountNumber) {
	        for (int i = 0; i < validAccountNumbers.length; i++) {
	            if (validAccountNumbers[i].equals(accountNumber)) {
	                return accountBalances[i];
	            }
	        }
	        return 0; // Default balance if account not found (you can handle this differently)
	    }
	    
	    //TASK-5
	    
	    private String password;
	    public String getPassword() {
	        return password;
	    }
	    public void setPassword(String password) {
	        this.password = password;
	    }
	    public boolean isValidPassword() {
	        if (password.length() < 8) {
	            return false;
	        }
	        if (!password.matches(".*[A-Z].*")) {
	            return false;
	        }
	        if (!password.matches(".*\\d.*")) {
	            return false;
	        }
	        return true;
	    }
	    
	    //TASK-6
	    
	    private List<Double> transactions;
	    public void BankTransactionM() {
	        transactions = new ArrayList<>();
	    }
	    public void addTransaction(double amount) {
	        transactions.add(amount);
	    }
	    public List<Double> getTransactions() {
	        return transactions;
	    }
 }
