package com.hexaware.view;

import java.util.List;

public class BankTransactionV {

	public void displayTransactions(List<Double> transactions) {
		// TODO Auto-generated method stub
		
	}

}
