package com.hexaware.view;

import java.util.List;
import java.util.Scanner;
import com.hexaware.view.OopView;

public class OopView {
	
	//TASK-1
	
	private Scanner scanner = new Scanner(System.in);
	public double getAnnualIncomeFromUser() {
	    System.out.print("Enter your annual income: ");
    return scanner.nextDouble();
	}
	public int getcreditScoreFromUser() {
	    System.out.print("Enter your credit score: ");
	    return scanner.nextInt();
	}
	public void displayEligibilityResult(boolean isEligible) {
	    if (isEligible) {
	    	System.out.println("Congratulations! You are eligible for the loan.");
	    } else {
	        System.out.println("Sorry, you are not eligible for the loan.");
	    }
	}
	
	//TASK-2
	
	public void displayMenu() {
	     System.out.println("\n1. Check Balance");
	     System.out.println("2. Withdraw");
	     System.out.println("3. Deposit");
	}
	public int getTransactionChoice() {
	     System.out.print("Enter your choice (1-3): ");
	     return scanner.nextInt();
	}
	public double getWithdrawalAmount() {
	     System.out.print("Enter withdrawal amount: ");
	     return scanner.nextDouble();
	}
	public double getDepositAmount() {
	     System.out.print("Enter deposit amount: ");
	     return scanner.nextDouble();
	}
	public void displayBalance(double balance) {
	     System.out.println("Your current balance: $" + balance);
	}
	public void displaySuccessMessage(String message) {
	     System.out.println("Success: " + message);
	}
	public void displayFailureMessage(String message) {
	     System.out.println("Failure: " + message);
	}
	
	//TASK-3
	 
	public double getDoubleInput(String prompt) {
	        System.out.print(prompt);
	        return scanner.nextDouble();
	}
	public int getIntInput(String prompt) {
	        System.out.print(prompt);
	        return scanner.nextInt();
	}
	public void displayFutureBalance(double futureBalance) {
	        System.out.println("Future Balance: $" + futureBalance);
	}
	
	//TASK-4
	
	public String getAccountNumber() {
	        System.out.print("\nEnter your account number: ");
	        return scanner.nextLine();
	}
	public void displayBalance1(double balance) {
	        System.out.println("Your account balance: $" + balance);
	}
	public void displayInvalidAccountMessage() {
	        System.out.println("Invalid account number. Please try again.");
	}
	
	//TASK-5
	
	public String getPasswordFromUser() {
	        System.out.print("\nEnter your password: ");
	        return scanner.nextLine();
	}
	public void displayPasswordValidity(boolean isValid) {
	        if (isValid) {
	            System.out.println("Password is valid.");
	        } else {
	            System.out.println("Invalid password. Please follow the password rules.");
	        }
	}
	
	//TASK-6
	    
	public void displayTransactions(List<Double> transactions) {
	        System.out.println("Transaction History:");
	        for (int i = 0; i < transactions.size(); i++) {
	            System.out.println((i + 1) + ". " + transactions.get(i));
	        }
	        System.out.println();
	}
}
