package com.hexaware.controller;

import com.hexaware.entity.BankTransactionM;
import com.hexaware.entity.OopModel;
import com.hexaware.view.BankTransactionV;
import com.hexaware.view.OopView;

public class OopController<Transaction> {
	
	//TASK-1
    
	private Object model;
    private OopView view1;
    public OopController(OopModel model, OopView view) {
        this.model = model;
        this.view1 = view;
    }
    public void LoanEligibility() {
    	int creditScore=view1.getcreditScoreFromUser();
        double annualIncome = view1.getAnnualIncomeFromUser();
        ((OopModel) model).setcreditScore(creditScore);
        ((OopModel) model).setAnnualIncome(annualIncome);
        boolean isEligible = ((OopModel) model).checkEligibility();
        view1.displayEligibilityResult(isEligible);
    }
    
    //TASK-2
    
	public void performTransaction() {
	    view1.displayMenu();
	    int choice = view1.getTransactionChoice();
	    switch (choice) {
	        case 1:
	            view1.displayBalance(((OopModel) model).getBalance());
	            break;
	        case 2:
	            withdraw();
	            break;
	        case 3:
	            deposit();
	            break;
	        default:
	            view1.displayFailureMessage("Invalid choice. Please enter a valid option.");
	        }
	    }
	private void withdraw() {
	    double withdrawalAmount = view1.getWithdrawalAmount();
	    if (withdrawalAmount % 100 == 0 || withdrawalAmount % 500 == 0) {
	        if (withdrawalAmount <= ((OopModel) model).getBalance()) {
	            ((OopModel) model).setBalance(((OopModel) model).getBalance() - withdrawalAmount);
	            view1.displaySuccessMessage("Withdrawal successful. Remaining balance: $" + ((OopModel) model).getBalance());
	        } else {
	            view1.displayFailureMessage("Insufficient funds.");
	        }
	    } else {
	        view1.displayFailureMessage("Withdrawal amount must be in multiples of 100 or 500.");
	    }
	}
	private void deposit() {
	    double depositAmount = view1.getDepositAmount();
	    ((OopModel) model).setBalance(((OopModel) model).getBalance() + depositAmount);
	    view1.displaySuccessMessage("Deposit successful. Updated balance: $" + ((OopModel) model).getBalance());
	    }
	
	//TASK-3
	
    public void calculateFutureBalance() {
        double initialBalance = view1.getDoubleInput("Enter initial balance: ");
        double annualInterestRate = view1.getDoubleInput("Enter annual interest rate (%): ");
        int years = view1.getIntInput("Enter the number of years: ");
        ((OopModel) model).setInitialBalance(initialBalance);
        ((OopModel) model).setAnnualInterestRate(annualInterestRate);
        ((OopModel) model).setYears(years);
        ((OopModel) model).calculateFutureBalance();
        view1.displayFutureBalance(((OopModel) model).getFutureBalance());
    }
    
    //TASK-4
    
    public void checkBalance() {
        String accountNumber;
        boolean isValidAccount = false;
        do {
            accountNumber = view1.getAccountNumber();
            isValidAccount = ((OopModel) model).isValidAccount(accountNumber);
            if (isValidAccount) {
                double balance = ((OopModel) model).getAccountBalance(accountNumber);
                view1.displayBalance1(balance);
            } else {
                view1.displayInvalidAccountMessage();
            }
        } while (!isValidAccount);
    }
    
    //TASK-5
    
    public void validatePassword() {
    String password = view1.getPasswordFromUser();
    ((OopModel) model).setPassword(password);
    boolean isValid = ((OopModel) model).isValidPassword();
    view1.displayPasswordValidity(isValid);
    }
    
    //TASK-6
    
    private BankTransactionM model1;
    private BankTransactionV view;
    public void BankTransactionC(BankTransactionM model1, BankTransactionV view) {
        this.model = model1;
        this.view = view;
    }
    public void addTransaction(double amount) {
        ((BankTransactionM) model).addTransaction(amount);
    }
    public void displayTransactions() {
        view.displayTransactions(((BankTransactionM) model).getTransactions());
    }
    public BankTransactionM getModel1() {
		return model1;
	}
    public void setModel1(BankTransactionM model1) {
		this.model1 = model1;
	}
}


