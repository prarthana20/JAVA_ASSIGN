package com.hexaware.controller;

import com.hexaware.entity.BankTransactionM;
import com.hexaware.view.BankTransactionV;

public class BankTransactionC {

	public BankTransactionC(BankTransactionM model1, BankTransactionV view1) {
		// TODO Auto-generated constructor stub
	}

	public void addTransaction(double amount) {
		// TODO Auto-generated method stub
		
	}

	public void displayTransactions() {
		// TODO Auto-generated method stub
		
	}

}
