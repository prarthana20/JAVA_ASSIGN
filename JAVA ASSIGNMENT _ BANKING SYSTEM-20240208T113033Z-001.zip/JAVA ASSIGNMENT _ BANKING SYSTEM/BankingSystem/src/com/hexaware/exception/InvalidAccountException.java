package com.hexaware.exception;

public class InvalidAccountException extends Exception {

	public InvalidAccountException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
