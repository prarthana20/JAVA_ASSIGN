package com.hexaware.dao;

import com.hexaware.exception.InsufficientFundsException;
import com.hexaware.exception.InvalidAccountException;
import com.hexaware.exception.OverDraftLimitExceededException;

public abstract class CustomerInterface {
	
	 	public abstract void addCustomer();

	    public abstract void viewCustomer();
	    
	    public abstract  void addAccount();

	    public abstract void viewAccount();

		public abstract void deposit(long accountId, float amount);

		public abstract void withdraw(long accountId, float amount);

		public abstract void calculateInterest(long accountId);

		abstract void transfer(long fromAccountId, long toAccountId, float amount)
				throws InsufficientFundsException, InvalidAccountException, OverDraftLimitExceededException;
}
